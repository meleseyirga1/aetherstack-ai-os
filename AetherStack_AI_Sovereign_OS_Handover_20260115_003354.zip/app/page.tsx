"use client"
import { useEffect, useState, useRef, useMemo } from 'react';
import { useSovereignVoice } from '../hooks/useSovereignVoice';
import { ShieldAlert, Zap, Globe, Cpu, Database, Binary } from 'lucide-react';
import FounderProfile from '../components/interface/FounderProfile';

export default function InfinityDashboard() {
  const [mounted, setMounted] = useState(false);
  const [input, setInput] = useState('');
  const [swarm, setSwarm] = useState([]);
  const [isAlert, setIsAlert] = useState(false);
  const [extraNodes, setExtraNodes] = useState([]);
  const [snapshot, setSnapshot] = useState(null);
  const { speak } = useSovereignVoice();

  useEffect(() => { setMounted(true); }, []);

  const handleCommand = async (e: any) => {
    if (e.key !== 'Enter' || !input) return;
    const cmd = input; setInput('');
    
    const res = await fetch('/api/alpha/command', { method: 'POST', body: JSON.stringify({ command: cmd }) });
    const data = await res.json();
    
    setSwarm(data.swarm || []);
    
    // 1. Alert Logic
    if (data.pre_crime?.status === "PREVENTED") {
        setIsAlert(true);
        speak("Pre-emptive interdiction successful. Threat neutralized at origin.");
        setTimeout(() => setIsAlert(false), 5000);
    }
    
    // 2. Scaling Logic
    if (data.new_nodes?.length > 0) {
        setExtraNodes(prev => [...new Set([...prev, ...data.new_nodes])]);
        speak("Global mesh expanded. New hubs anchored.");
    }

    // 3. Synthesis Logic
    if (data.snapshot) {
        setSnapshot(data.snapshot);
        speak("Planetary memory synthesized. Quantum root locked.");
    }
  };

  if (!mounted) return null;

  return (
    <div style={{ background: isAlert ? '#1a0000' : 'black', transition: 'background 1s ease' }} className="min-h-screen text-white font-mono p-10 lg:p-20 overflow-hidden relative">
      
      {/* HEADER */}
      <div className="flex justify-between items-start mb-12 relative z-10">
        <div>
           <h1 className="text-4xl font-black italic tracking-tighter uppercase">AetherStack<span className="text-cyan-500">AI</span></h1>
           <p className="text-[#333] text-[10px] mt-2 tracking-[0.4em] uppercase font-bold">
             {isAlert ? '⚠️ PRE_CRIME_INTERDICTION_ACTIVE' : 'Sovereign OS v∞ // Multi-Core'}
           </p>
        </div>
        <FounderProfile name="Founder Yirga" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 relative z-10">
        
        {/* LEFT: COMMAND & SWARM (2 Columns) */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-[#080808]/80 border border-white/5 rounded-[40px] p-10 backdrop-blur-xl shadow-2xl">
            <div className="flex gap-6 items-center border-b border-white/5 pb-8 mb-8">
              <span className="text-cyan-500 text-5xl font-black italic">λ</span>
              <input value={input} onChange={(e)=>setInput(e.target.value)} onKeyDown={handleCommand} placeholder="ISSUE MASTER DIRECTIVE..." className="bg-transparent border-none outline-none text-2xl font-black w-full text-white" autoFocus />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {swarm.map((s, i) => (
                <div key={i} className="p-4 bg-white/5 rounded-2xl border border-white/5 animate-in fade-in">
                  <div className="text-[8px] text-cyan-500 font-black mb-1 uppercase tracking-widest">{s.agent}</div>
                  <div className="text-[10px] text-zinc-400 italic">"{s.msg}"</div>
                </div>
              ))}
            </div>
          </div>

          {/* DYNAMIC FLEET VISUALIZER */}
          <div className="bg-[#050505] border border-white/5 rounded-[30px] p-10">
             <div className="flex justify-between mb-8">
                <span className="text-[10px] text-zinc-600 font-black uppercase tracking-widest">Global Node Consensus</span>
                <span className="text-cyan-500 text-xs font-bold font-mono">1000 + {extraNodes.length} CELLS</span>
             </div>
             <div className="flex flex-wrap gap-3">
                {['NYC', 'LON', 'FRA', 'SGP', 'TYO', 'SYD', ...extraNodes].map((node, i) => (
                   <div key={i} className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 rounded text-[9px] font-bold text-cyan-400 animate-pulse">
                     ● {node}
                   </div>
                ))}
             </div>
          </div>
        </div>

        {/* RIGHT: SYNTHESIS REPORT (1 Column) */}
        <div className="space-y-8">
          {snapshot ? (
            <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-[30px] p-10 animate-in zoom-in-95 duration-1000 shadow-[0_0_50px_rgba(16,185,129,0.1)]">
               <div className="flex items-center gap-2 text-emerald-500 mb-6">
                  <Binary size={16} />
                  <span className="text-[10px] font-black uppercase tracking-widest">Quantum Synthesis Seal</span>
               </div>
               <div className="space-y-6">
                  <div>
                    <div className="text-[7px] text-zinc-600 uppercase mb-1">Root Signature</div>
                    <div className="text-[10px] font-bold text-white break-all">{snapshot.root_hash}</div>
                  </div>
                  <div className="flex justify-between border-t border-white/5 pt-4">
                    <div>
                      <div className="text-[7px] text-zinc-600 uppercase mb-1">Coherence</div>
                      <div className="text-lg font-bold text-emerald-400">{snapshot.coherence}</div>
                    </div>
                    <div>
                      <div className="text-[7px] text-zinc-600 uppercase mb-1">Synapses</div>
                      <div className="text-lg font-bold text-white">{snapshot.synapses.toLocaleString()}</div>
                    </div>
                  </div>
               </div>
            </div>
          ) : (
            <div className="h-[500px] border border-dashed border-white/5 rounded-[30px] flex flex-col items-center justify-center text-zinc-800 text-[10px] uppercase tracking-[1em] [writing-mode:vertical-lr]">
               Awaiting_Consensus_Singularity
            </div>
          )}
        </div>

      </div>
    </div>
  );
}