"use client"
import { useCallback, useEffect, useState } from 'react';

export const useSovereignVoice = () => {
  const [voice, setVoice] = useState<SpeechSynthesisVoice | null>(null);

  useEffect(() => {
    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      // Priority: Google US English -> Premium -> Any English -> First Available
      const preferred = voices.find(v => v.name.includes('Google US English')) || 
                        voices.find(v => v.lang.includes('en-US')) || 
                        voices[0];
      setVoice(preferred);
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }, []);

  const speak = useCallback((text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;

    // Force stop previous speech
    window.speechSynthesis.cancel(); 
    
    const utterance = new SpeechSynthesisUtterance(text);
    if (voice) utterance.voice = voice;
    
    // SOVEREIGN TONE SETTINGS
    utterance.pitch = 0.65; 
    utterance.rate = 0.85;   
    utterance.volume = 1.0; // MAX VOLUME

    window.speechSynthesis.speak(utterance);
    console.log("🔊 COMMANDER_AUDIO_STREAM: " + text);
  }, [voice]);

  return { speak };
};