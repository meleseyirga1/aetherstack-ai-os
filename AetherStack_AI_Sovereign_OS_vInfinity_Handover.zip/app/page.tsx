"use client"
import { useEffect, useState } from 'react';
import { useSovereignVoice } from '../hooks/useSovereignVoice';
import FounderProfile from '../components/interface/FounderProfile';

export default function SovereignDashboard() {
  const [mounted, setMounted] = useState(false);
  const [input, setInput] = useState('');
  const [swarm, setSwarm] = useState([]);
  const [isPreCrime, setIsPreCrime] = useState(false);
  const { speak } = useSovereignVoice();

  useEffect(() => { setMounted(true); }, []);

  const handleCommand = async (e: any) => {
    if (e.key !== 'Enter' || !input) return;
    const cmd = input; setInput(''); setSwarm([]);
    
    const res = await fetch('/api/alpha/command', { 
        method: 'POST', 
        body: JSON.stringify({ command: cmd }) 
    });
    const data = await res.json();
    
    setSwarm(data.swarm || []);

    if (data.pre_crime?.status === "THREAT_INCEPTION_DETECTED") {
        setIsPreCrime(true);
        speak("Pre-emptive interdiction successful. Threat neutralized at origin.");
        // Keep the purple alert visible for 8 seconds
        setTimeout(() => setIsPreCrime(false), 8000);
    } else {
        speak(data.output);
    }
  };

  if (!mounted) return null;

  return (
    <div style={{ 
        background: isPreCrime ? '#1a0033' : 'black', 
        transition: 'background 2s cubic-bezier(0.4, 0, 0.2, 1)' 
    }} className="min-h-screen text-white font-mono p-10 lg:p-20 overflow-hidden relative">
      
      {/* 📡 THE NEURAL RADAR RING */}
      {isPreCrime && (
        <div className="fixed inset-0 pointer-events-none flex items-center justify-center">
          <div className="w-[800px] h-[800px] border-4 border-purple-500/20 rounded-full animate-ping" />
          <div className="absolute w-[400px] h-[400px] border-2 border-purple-500/40 rounded-full animate-pulse" />
        </div>
      )}

      <div className="relative z-10 flex flex-col h-full">
        {/* HEADER */}
        <div className="flex justify-between items-start mb-12">
          <div>
            <h1 className="text-3xl font-black italic tracking-tighter">AETHERSTACK<span className="text-cyan-500">AI</span></h1>
            <p className="text-zinc-600 text-[10px] mt-1 tracking-widest uppercase">ERA-19 // PRE_COGNITIVE_OS</p>
          </div>
          <div className="flex gap-4 items-center">
             {isPreCrime && (
                <div className="px-3 py-1 bg-purple-500 text-white rounded text-[8px] font-black animate-bounce">
                  PRE_CRIME_INTERDICTION_ACTIVE
                </div>
             )}
             <FounderProfile name="Founder Yirga" />
          </div>
        </div>

        {/* TERMINAL */}
        <div style={{ 
            background: isPreCrime ? '#0d001a' : '#080808', 
            border: isPreCrime ? '2px solid #a855f7' : '1px solid #1a1a1a',
            boxShadow: isPreCrime ? '0 0 100px rgba(168, 85, 247, 0.3)' : 'none'
        }} className="max-w-4xl mx-auto w-full rounded-[40px] p-12 shadow-2xl transition-all duration-1000">
          <div className="flex gap-6 items-center border-b border-white/5 pb-8 mb-8">
            <span className={isPreCrime ? 'text-purple-500 text-5xl italic font-black' : 'text-cyan-500 text-5xl italic font-black'}>λ</span>
            <input 
              value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={handleCommand}
              placeholder={isPreCrime ? "THREAT NEUTRALIZED." : "ISSUE MASTER DIRECTIVE..."}
              className="bg-transparent border-none outline-none text-3xl font-black w-full text-white placeholder:text-zinc-900"
              autoFocus
            />
          </div>
          <div className="space-y-6">
            {swarm.map((s: any, i: number) => (
              <div key={i} className="animate-in fade-in slide-in-from-left-2 duration-500 text-sm flex gap-4">
                <span className={s.status === 'PREVENTED' ? 'text-purple-400 font-black px-2 bg-purple-500/10 rounded' : 'text-cyan-500 font-bold'}>
                    [{s.agent}]
                </span>
                <span className={s.status === 'PREVENTED' ? 'text-zinc-200 font-bold italic' : 'text-zinc-500 italic'}>
                    "{s.msg}"
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}